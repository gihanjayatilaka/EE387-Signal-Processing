function x = rect( t )
    x = abs(t) <= 0.5 ;    
end

